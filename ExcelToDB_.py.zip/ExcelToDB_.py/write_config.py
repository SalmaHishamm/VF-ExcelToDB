import cx_Oracle
import pandas as pd
import re
import json


def readConfig () :
 with open("config.json") as f:
  config = json.load(f)

  str= config["Database"]
  return str




def clean (number): 

  pattern = re.compile("[^\d]")
  print (pattern)
  new_number = pattern.sub("", str(number))
  return new_number


    

try:
    
    file_path='Table.xlsx'
    sheet_name='Sheet1'
    df = pd.read_excel(file_path,sheet_name)
    
    
    
    ConnStr=readConfig ()
    connection = cx_Oracle.connect(ConnStr)
    cursor=connection.cursor()
    
    col1=df['CouponValue']
    col2=df['Code']
    col3=df['DiscountID']
    col4=df['TransactionID']
    
    col1_list=col1.tolist()
    col2_list=col2.tolist()
    col3_list=col3.tolist()
    col4_list=col4.tolist()
    
    # print(col1_list)
    # print(col2_list)
    # print(col3_list)
    # print(col4_list)
    
    i=0
    n=len(col1_list)
    
    insert_statement = "INSERT INTO coupons (COUPONVALUE,CODE,DISCOUNTID,DISCOUNTTYPE,DEALTYPE,TRANSACTIONID,ECODE,EDESC) VALUES (:val1, :val2 , :val3 , 'ss','ss',:val4 ,2,'ss')"
    print (n)
    for i in range(0,n) :
     
     value1=clean(col1_list[i])
     value2=col2_list[i]
     value3=col3_list[i]
     value4=col4_list[i]
     
     
     cursor.execute(insert_statement, {"val1": str(value1), "val2": str(value2) , "val3": str(value3) , "val4": str(value4)})
     
     #cursor.execute(insert_statement)
     #cursor.execute( "INSERT INTO Coupons (COUPONVALUE,CODE,DISCOUNTID,DISCOUNTTYPE,DEALTYPE,TRANSACTIONID,ECODE,EDESC) VALUES (1,str(value2),str(value3),'ss','ss',str(value4),2,'ss')")
     connection.commit() 
    cursor.close()
     
     
     
    #  result=""
     
except pd.errors.EmptyDataError:
    print("The Excel file is empty or has no data.")
except FileNotFoundError:
    print("File 'Table.xlsx' not found or incorrect file path.")
except cx_Oracle.DatabaseError as e:
    print ("An error occurred:", e)
except Exception as e:
    print("An error occurred:", e)



#cursor.execute( "INSERT INTO Coupons (COUPONVALUE, CODE,DISCOUNTID,DISCOUNTTYPE,DEALTYPE,TRANSACTIONID,ECODE,EDESC) VALUES (1,'ss','ss','ss','ss','ss',2,'ss')")
# connection.commit() 
# cursor.close()
